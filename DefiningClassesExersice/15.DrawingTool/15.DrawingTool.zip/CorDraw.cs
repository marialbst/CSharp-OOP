﻿namespace _15.DrawingTool
{
    public class CorDraw
    {
        public CorDraw(Rectangle rect)
        {
            rect.Draw();
        }
    }
}
