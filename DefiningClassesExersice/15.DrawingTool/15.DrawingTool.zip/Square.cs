﻿namespace _15.DrawingTool
{
    public class Square : Rectangle
    {

        public Square(int side):base()
        {
            this.Width = side;
            this.Height = side;
        }
    }
}
