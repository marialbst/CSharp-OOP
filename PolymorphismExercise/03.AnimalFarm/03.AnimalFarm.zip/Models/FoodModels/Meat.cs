﻿namespace _03.AnimalFarm.Models.FoodModels
{
    public class Meat : Food
    {
        public Meat(int quantity)
            :base(quantity)
        {
        }
    }
}
