﻿namespace _03.AnimalFarm.Models.FoodModels
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity)
            :base(quantity)
        {
            
        }
    }
}
